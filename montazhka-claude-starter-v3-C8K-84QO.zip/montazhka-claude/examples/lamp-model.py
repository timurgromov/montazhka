import bpy
import math
import sys
from pathlib import Path

bpy.ops.wm.read_factory_settings(use_empty=True)

def material(name, rgb, metal=0.0):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    shader = mat.node_tree.nodes['Principled BSDF']
    shader.inputs['Base Color'].default_value = (*rgb, 1)
    shader.inputs['Metallic'].default_value = metal
    shader.inputs['Roughness'].default_value = .32
    return mat

ivory = material('Ivory shell', (.68,.52,.29), .22)
navy = material('Navy frame', (.024,.043,.077), .15)
blue = material('Blue service panel', (.02,.20,.68), .15)
orange = material('Orange lens', (.96,.20,.017))
bronze = material('Bronze fasteners', (.54,.29,.08), .65)

def finish(name, mat, bevel):
    obj = bpy.context.object
    obj.name = name
    obj.data.materials.append(mat)
    if bevel:
        mod = obj.modifiers.new('Rounded edges', 'BEVEL')
        mod.width = bevel
        mod.segments = 3
        obj.modifiers.new('Weighted normals', 'WEIGHTED_NORMAL')
    return obj

def box(name, size, at, mat, bevel=.04):
    bpy.ops.mesh.primitive_cube_add(size=1,location=at)
    bpy.context.object.dimensions = size
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    finish(name,mat,bevel)

def cylinder(name, radius, depth, at, mat, rotation=(0,0,0)):
    bpy.ops.mesh.primitive_cylinder_add(vertices=48, radius=radius, depth=depth, location=at, rotation=rotation)
    finish(name,mat,.012)

box('Heavy oval-style base', (1.45,1.1,.18), (0,0,.09), navy, .08)
box('Upright support', (.37,.35,.63), (0,.12,.48), bronze)
box('Lamp housing', (1.15,.88,.93), (0,.05,1.12), ivory, .10)
front = (math.pi/2,0,0)
cylinder('Rim', .39,.13,(0,-.42,1.13),navy,front)
cylinder('Lens bezel', .33,.13,(0,-.49,1.13),bronze,front)
cylinder('Orange frosted lens', .28,.09,(0,-.56,1.13),orange,front)
box('Blue panel', (.08,.60,.62), (.61,.07,1.12), blue)
for z in [1.0,1.12,1.24]:
    box('Panel vent',(.03,.34,.035),(.656,.07,z),navy,.01)
for y in [-.15,.29]:
    for z in [.88,1.36]:
        cylinder('Panel screw',.025,.025,(.66,y,z),bronze,(0,math.pi/2,0))
box('Switch', (.17,.24,.14), (.24,.19,1.62), orange)
bpy.ops.export_scene.gltf(filepath=str(Path(sys.argv[-1]).resolve()),export_format='GLB', export_apply=True)
