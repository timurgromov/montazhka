import {AbsoluteFill, Composition, Easing, getStaticFiles, Html5Audio, Sequence, interpolate, registerRoot, staticFile, useCurrentFrame} from 'remotion';

type Point = readonly [number, number];
const duration = 230;
const beats = [
  {from:0, to:50, text:'Мира нашла ключ.'},
  {from:50, to:110, text:'Она передала его Тиму.'},
  {from:110, to:165, text:'Тим открыл коробку.'},
  {from:165, to:230, text:'Внутри загорелась звезда.'},
];
const ease = (f:number, a:number, b:number) => interpolate(f,[a,b],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:Easing.inOut(Easing.cubic)});
const mix = (a:Point,b:Point,p:number):Point => [a[0]+(b[0]-a[0])*p,a[1]+(b[1]-a[1])*p];
const ink='#243743';
const star='0,-48 12,-15 47,-14 19,7 28,42 0,21 -28,42 -19,7 -47,-14 -12,-15';

function Puppet({x,scale,kind,hand,otherHand,happy}:{x:number;scale:number;kind:'mira'|'tim';hand:Point;otherHand?:Point;happy:boolean}) {
  const mira=kind==='mira', color=mira?'#a95042':'#3c6c70', face='#e6ad7b';
  const shoulder:Point=[x+(mira?23:-23)*scale,407-102*scale];
  const arm=(a:Point,b:Point)=> <g><path d={`M${a[0]} ${a[1]} Q${(a[0]+b[0])/2} ${Math.max(a[1],b[1])+18*scale} ${b[0]} ${b[1]}`} stroke={color} strokeWidth={14*scale} fill="none" strokeLinecap="round"/><circle cx={b[0]} cy={b[1]} r={8*scale} fill={face}/></g>;
  return <g data-character={kind}>
    <ellipse cx={x} cy={407} rx={37*scale} ry={5} fill="#263c50" opacity=".18"/>
    {otherHand && arm([x+23*scale,407-102*scale],otherHand)}
    <g transform={`translate(${x} 407) scale(${scale})`}>
      <path d="M-15 -66 L-18 -9 M15 -66 L17 -9" stroke={ink} strokeWidth="12" strokeLinecap="round"/>
      <path d="M-29 0 h19 M9 0 h21" stroke={ink} strokeWidth="9" strokeLinecap="round"/>
      <path d="M-22 -113 Q0 -126 24 -111 L39 -60 Q3 -51 -39 -61Z" fill={color}/>
      {mira ? <path d="M-18 -109 L7 -84 L20 -110" stroke="#f5d787" strokeWidth="8" fill="none"/> : <path d="M-23 -85 H23" stroke="#c3ded2" strokeWidth="8"/>}
      {mira&&<path d="M-22 -163 C-66 -184 -68 -125 -35 -125 L-16 -144Z" fill={ink}/>}
      <circle cy="-147" r="34" fill={face}/>
      {mira?<path d="M-34 -151 Q-28 -197 13 -179 Q26 -177 35 -155 Q14 -157 5 -171 Q-8 -150 -34 -151Z" fill={ink}/>:
        <path d="M-36 -153 Q-34 -193 5 -187 Q34 -188 36 -158 L42 -150Z" fill="#345d67"/>}
      <circle cx={mira?8:-14} cy="-145" r="3.6" fill={ink}/><circle cx={mira?22:1} cy="-145" r="3.6" fill={ink}/>
      <path d={happy?(mira?'M7 -134 q8 12 16 0':'M-15 -134 q8 12 16 0'):(mira?'M8 -132 q7 3 13 -1':'M-14 -132 q7 3 13 -1')} fill="none" stroke={ink} strokeWidth="2.8" strokeLinecap="round"/>
    </g>{arm(shoulder,hand)}
  </g>;
}

function Workshop({from}:{from:number}) {
  const f=useCurrentFrame()+from;
  const pickup:Point=[419,364], miraUp:Point=[425,277], meet:Point=[471,306], timUp:Point=[523,278], lock:Point=[608,357];
  const mira = f<24?mix([405,329],pickup,ease(f,8,24)):f<50?mix(pickup,miraUp,ease(f,24,43)):f<83?mix(miraUp,meet,ease(f,57,83)):mix(meet,[410,332],ease(f,86,108));
  const tim = f<83?mix([527,330],meet,ease(f,64,83)):f<111?mix(meet,timUp,ease(f,86,108)):f<137?mix(timUp,lock,ease(f,115,136)):mix(lock,[549,329],ease(f,139,150));
  const key = f<24?pickup:f<85?mira:f<136?tim:lock;
  const open=ease(f,136,158), angle=-1.05*open;
  const lidHand:Point=[589+51*Math.cos(angle),324+51*Math.sin(angle)];
  const other=f<136?mix([580,331],[640,324],ease(f,112,136)):f<162?lidHand:mix(lidHand,[583,286],ease(f,162,179));
  const reveal=ease(f,166,195);
  const push=ease(f,50,84);
  return <svg viewBox={`${150*push} ${70*push} ${960-250*push} ${540-140.625*push}`} width="100%" height="100%" aria-label="Мира передаёт ключ Тиму в бумажной мастерской">
    <defs><pattern id="paper" width="19" height="13" patternUnits="userSpaceOnUse"><circle cx="3" cy="5" r=".7" fill="#48392d" opacity=".12"/><circle cx="15" cy="9" r=".55" fill="#66786d" opacity=".17"/></pattern></defs>
    <path d="M0 0H960V540H0Z" fill="#f1e6d0"/>
    <path d="M0 402 Q450 398 960 404V540H0Z" fill="#d9bb90"/>
    <path d="M44 280V59H204V280Z" fill="#c79b71"/><path d="M54 271V70H194V271Z" fill="#abc1b3"/>
    <path d="M57 205l55 -42 65 53v52H57Z" fill="#6c988b" opacity=".55"/><path d="M124 70V270 M54 160H193" stroke="#f1e6d0" strokeWidth="8"/>
    <path d="M794 40v105m-42 15 12-28h60l12 28Z" fill="#e1b464" stroke="#d0a65e" strokeWidth="5"/>
    <path d="M410 384v22m47-22v22" stroke="#9b6c43" strokeWidth="9"/><path d="M399 372h73l-4 13h-65Z" fill="#b08458"/>
    <ellipse cx="650" cy="410" rx="84" ry="8" fill="#4f4b3d" opacity=".18"/>
    <g data-prop="box"><rect x="589" y="328" width="125" height="73" rx="5" fill="#a45d44"/>
      <path d="M591 330h121l-11 19h-99Z" fill={open>.12?'#573d38':'#be7855'}/>
      <rect x="617" y="348" width="17" height="20" rx="4" fill="#e3b14f"/><path d="M625 353v9" stroke={ink} strokeWidth="3"/>
      <g transform={`rotate(${angle*180/Math.PI} 589 324)`}><rect x="589" y="317" width="125" height="15" rx="4" fill="#b77555"/><path d="M596 320h109" stroke="#e3a37d" strokeWidth="2"/></g>
    </g>
    <Puppet x={379} scale={1} kind="mira" hand={mira} happy={f>=42}/>
    <Puppet x={553} scale={.82} kind="tim" hand={tim} otherHand={other} happy={f>=165}/>
    <g data-prop="key" transform={`translate(${key[0]} ${key[1]})`} stroke="#f6cc64" strokeWidth="5" fill="none" strokeLinecap="round"><circle cx="-3" r="6"/><path d="M3 0h17v5m-6-5v4"/></g>
    {reveal>0 && <g transform={`translate(652 ${330-119*reveal}) scale(${.23+.77*reveal})`} opacity={reveal}>
      <circle r="70" fill="#f6cc64" opacity=".25"/><polygon points={star} fill="#ffce65" stroke="#dc8d38" strokeWidth="3"/>
      <path d="M-67 0h-17 M67 0h17 M0 -66v-16" stroke="#edab47" strokeWidth="4" strokeLinecap="round"/>
    </g>}
    <path d="M0 0H960V540H0Z" fill="url(#paper)" pointerEvents="none"/>
  </svg>;
}

function Cartoon(){return <AbsoluteFill style={{background:'#f1e6d0'}}>
  {beats.map(b=><Sequence key={b.from} name={b.text} from={b.from} durationInFrames={b.to-b.from}>
    <Workshop from={b.from}/><div style={{position:'absolute',bottom:30,left:0,right:0,textAlign:'center',font:'620 27px system-ui',color:ink}}>{b.text}</div>
  </Sequence>)}
  {getStaticFiles().some(file => file.name === 'story.wav') && <Html5Audio name="Голос рассказчика" src={staticFile('story.wav')}/>}
</AbsoluteFill>}
registerRoot(()=> <Composition id="PaperKey" component={Cartoon} width={960} height={540} fps={25} durationInFrames={duration}/>);
