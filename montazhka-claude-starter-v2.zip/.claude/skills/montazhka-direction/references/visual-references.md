# Визуальная концепция: справочник

После синопсиса автор и агент обсуждают сеттинг, стиль, палитру, движение и глубину. Плоское 2D, многослойное 2,5D с параллаксом и трёхмерное 3D — разные варианты глубины, их можно сочетать со стилями. Возможные стили: рисунок от руки, бумажный коллаж, вектор, комиксы, пиксельная графика, кинетическая типографика, неоновая графика, стилизованное 3D и интерфейсная графика. Это примеры, а не закрытый перечень.

Если автор поручил подбор, ищи конкретные подходящие работы, посмотри 2–3 доступных примера и опиши приём, момент и сцену применения. Если не удалось просмотреть движение или примеров меньше — прямо сообщи. Учитывай авторские права и условия использования отдельно для каждого материала.

## Площадки
- [Oneshotted](https://oneshotted.io/)
- [Dribbble: motion design](https://dribbble.com/tags/motion-design)
- [Prompt Motion](https://prompt-motion.com/)
- [Motion Array](https://motionarray.com/motion-graphics-templates/)

## Каналы
- [Kurzgesagt](https://www.youtube.com/@kurzgesagt)
- [Historically](https://www.youtube.com/@HeyHistorically)
- [Day One Films](https://www.youtube.com/@dayonefilmsofficial)
- [MinuteEarth](https://www.youtube.com/@MinuteEarth)
- [GeoMapAnimations](https://www.youtube.com/@GeoMapAnimations)
